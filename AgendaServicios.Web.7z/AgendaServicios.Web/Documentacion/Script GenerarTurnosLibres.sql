CREATE PROCEDURE dbo.GenerarTurnosLibres
    @FechaTurnoDesde DATE,
    @FechaTurnoHasta DATE,
    @HoraTurnoDesde TIME,
    @HoraTurnoHasta TIME,
    @Intervalo TIME,
    @Lunes BIT,
    @Martes BIT,
    @Miercoles BIT,
    @Jueves BIT,
    @Viernes BIT,
    @Sabado BIT,
    @Domingo BIT
AS
BEGIN
	-- Variables para el Estado de Turno Libre
	DECLARE @EstadoTurnoIdLibre INT = 1

	-- Variables para el control de los bucles
    DECLARE @FechaActual DATE = @FechaTurnoDesde
    DECLARE @HoraActual TIME
	
	-- Bucle principal para las fechas
    WHILE @FechaActual <= @FechaTurnoHasta
    BEGIN
		-- Verificar si el d�a de la semana est� activo
        IF (DATEPART(dw, @FechaActual) = 1 AND @Lunes = 1) OR
           (DATEPART(dw, @FechaActual) = 2 AND @Martes = 1) OR
           (DATEPART(dw, @FechaActual) = 3 AND @Miercoles = 1) OR
           (DATEPART(dw, @FechaActual) = 4 AND @Jueves = 1) OR
           (DATEPART(dw, @FechaActual) = 5 AND @Viernes = 1) OR
           (DATEPART(dw, @FechaActual) = 6 AND @Sabado = 1) OR
           (DATEPART(dw, @FechaActual) = 7 AND @Domingo = 1)
        BEGIN
			-- Bucle para los intervalos de tiempo
            SET @HoraActual = @HoraTurnoDesde
            WHILE @HoraActual < @HoraTurnoHasta
            BEGIN
				-- Insertar el turno
                INSERT INTO Turnos (FechaTurno, HoraTurno, EstadoTurnoId, ClienteId, ServicioId, Observacion)
                VALUES (@FechaActual, @HoraActual, @EstadoTurnoIdLibre, NULL, NULL, NULL)

				-- Incrementar el tiempo
                SET @HoraActual = DATEADD(minute, DATEDIFF(minute, '00:00:00', @Intervalo), @HoraActual)
            END
        END

		-- Incrementar la fecha en un d�a
        SET @FechaActual = DATEADD(day, 1, @FechaActual)
    END
END
