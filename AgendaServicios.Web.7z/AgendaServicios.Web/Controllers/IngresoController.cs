﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AgendaServicios.Web.Data;
using AgendaServicios.Web.Models;

namespace AgendaServicios.Web.Controllers
{
	public class IngresoController : Controller
	{
		private readonly ApplicationDbContext _context;

		public IngresoController(ApplicationDbContext context)
		{
			_context = context;
		}

		[HttpGet]
		public IActionResult Index()
		{
			ViewBag.HideHeader = true;
			return View();
		}

		[HttpPost]
		public IActionResult Index(string numeroDocumento, string email)
		{
			var cliente = (from c in _context.Clientes
						   where c.NumeroDocumento.ToString() == numeroDocumento || c.CorreoElectronico == email
						   select c).FirstOrDefault();

			ViewBag.HideHeader = true;

			if (cliente == null)
			{
				ViewBag.ErrorMessage = "Cliente no encontrado";
				return View();
			}
			return RedirectToAction("IniciarReservaTurno", "Turnos", new { clienteId = cliente.ClienteId });
		}

	}
}
