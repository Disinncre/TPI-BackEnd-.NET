﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AgendaServicios.Web.Data;
using AgendaServicios.Web.Models;

namespace AgendaServicios.Web.Controllers
{
	public class ServiciosController : Controller
	{
		private readonly ApplicationDbContext _context;

		public ServiciosController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET: Servicios
		public async Task<IActionResult> Index()
		{
			var servicios = await _context.Servicios.ToListAsync();
			return View(servicios);
		}

		// GET: Servicios/Details/5
		public async Task<IActionResult> Details(int? id)
		{
			if (id == null || _context.Servicios == null)
			{
				return NotFound();
			}

			var servicio = await _context.Servicios
				.Include(s => s.TipoServicio)
				.FirstOrDefaultAsync(m => m.ServicioId == id);
			if (servicio == null)
			{
				return NotFound();
			}

			return View(servicio);
		}

		// GET: Servicios/Create
		public IActionResult Create()
		{
			ViewData["TipoServicioId"] = new SelectList(_context.TiposServicios, "TipoServicioId", "Descripcion");
			return View();
		}

		// POST: Servicios/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to.
		// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("ServicioId,Descripcion,Precio,Duracion,Observacion,TipoServicioId")] Servicio servicio)
		{
			if (ModelState.IsValid)
			{
				_context.Add(servicio);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			ViewData["TipoServicioId"] = new SelectList(_context.TiposServicios, "TipoServicioId", "Descripcion", servicio.TipoServicioId);
			return View(servicio);
		}

		// GET: Servicios/Edit/5
		public async Task<IActionResult> Edit(int? id)
		{
			if (id == null || _context.Servicios == null)
			{
				return NotFound();
			}

			var servicio = await _context.Servicios.FindAsync(id);
			if (servicio == null)
			{
				return NotFound();
			}
			ViewData["TipoServicioId"] = new SelectList(_context.TiposServicios, "TipoServicioId", "Descripcion", servicio.TipoServicioId);
			return View(servicio);
		}

		// POST: Servicios/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to.
		// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, [Bind("ServicioId,Descripcion,Precio,Duracion,Observacion,TipoServicioId")] Servicio servicio)
		{
			if (id != servicio.ServicioId)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(servicio);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!ServicioExists(servicio.ServicioId))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			ViewData["TipoServicioId"] = new SelectList(_context.TiposServicios, "TipoServicioId", "Descripcion", servicio.TipoServicioId);
			return View(servicio);
		}

		// GET: Servicios/Delete/5
		public async Task<IActionResult> Delete(int? id)
		{
			if (id == null || _context.Servicios == null)
			{
				return NotFound();
			}

			var servicio = await _context.Servicios
				.Include(s => s.TipoServicio)
				.FirstOrDefaultAsync(m => m.ServicioId == id);
			if (servicio == null)
			{
				return NotFound();
			}

			return View(servicio);
		}

		// POST: Servicios/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(int id)
		{
			if (_context.Servicios == null)
			{
				return Problem("Entity set 'ApplicationDbContext.Servicios'  is null.");
			}
			var servicio = await _context.Servicios.FindAsync(id);
			if (servicio != null)
			{
				_context.Servicios.Remove(servicio);
			}

			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		private bool ServicioExists(int id)
		{
			return (_context.Servicios?.Any(e => e.ServicioId == id)).GetValueOrDefault();
		}
	}
}
