﻿namespace AgendaServicios.Web.Models
{
	public enum EstadoTurnoEnum 
	{
		Libre = 1,
		Asignado = 2,
		Reservado = 3,
		Confirmado = 4,
		Atendido = 5,
		Anulado = 6
	}
}
